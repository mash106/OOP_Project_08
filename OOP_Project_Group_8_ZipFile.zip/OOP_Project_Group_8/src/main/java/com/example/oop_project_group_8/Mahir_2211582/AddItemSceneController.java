package com.example.oop_project_group_8.Mahir_2211582;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class AddItemSceneController {

    @FXML
    private TextArea descriptionArea;

    @FXML
    private TextField itemNameField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField quantityField;

    @FXML
    private TextField skuField;

    @FXML
    public void addItemToInventoryButtonOnAction(ActionEvent actionEvent) {
    }
}
