package com.example.oop_project_group_8.Mahir_2211582;

import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ContactSupportSceneController
{
    @javafx.fxml.FXML
    private ComboBox supportIssueComboBox;
    @javafx.fxml.FXML
    private TextArea supportMessageTextArea;
    @javafx.fxml.FXML
    private TextField customerSupportnameField;
    @javafx.fxml.FXML
    private TextField customerSupportemailField;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void submitSupportTicketButtonOnClicked(ActionEvent actionEvent) {
    }
}