package com.example.oop_project_group_8.Mahir_2211582;

import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;

public class RestockLowItemSceneController
{
    @javafx.fxml.FXML
    private TableView restockItemsTable;
    @javafx.fxml.FXML
    private ComboBox supplierComboBox;

    @javafx.fxml.FXML
    public void initialize() {
    }}