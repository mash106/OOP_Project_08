package com.example.oop_project_group_8.Mahir_2211582;

import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class TrackingOrderSceneController
{
    @javafx.fxml.FXML
    private Label orderDetailsLabel;
    @javafx.fxml.FXML
    private TableView orderTable;
    @javafx.fxml.FXML
    private Label shipmentDetailsLabel;
    @javafx.fxml.FXML
    private TableColumn datePlacedTC;
    @javafx.fxml.FXML
    private TableColumn totalAmountTC;
    @javafx.fxml.FXML
    private TableColumn timePlacedTC;
    @javafx.fxml.FXML
    private TableColumn orderIdTC;
    @javafx.fxml.FXML
    private TableColumn shipmentStatusTC;
    @javafx.fxml.FXML
    private TableColumn paymentStatusTC;

    @javafx.fxml.FXML
    public void initialize() {
    }}