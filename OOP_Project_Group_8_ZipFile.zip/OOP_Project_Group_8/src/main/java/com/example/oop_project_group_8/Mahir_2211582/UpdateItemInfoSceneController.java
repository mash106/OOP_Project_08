package com.example.oop_project_group_8.Mahir_2211582;

import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class UpdateItemInfoSceneController
{
    @javafx.fxml.FXML
    private ComboBox selectItemComboBox;
    @javafx.fxml.FXML
    private TextField updatedNameField;
    @javafx.fxml.FXML
    private TextArea updatedDescriptionArea;
    @javafx.fxml.FXML
    private TextField updatedQuantityField;
    @javafx.fxml.FXML
    private TextField updatedPriceField;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void updateItemInInventoryButtonOnClicked(ActionEvent actionEvent) {
    }
}