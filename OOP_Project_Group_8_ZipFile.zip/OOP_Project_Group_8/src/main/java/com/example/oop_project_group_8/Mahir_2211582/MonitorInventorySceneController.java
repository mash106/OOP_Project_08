package com.example.oop_project_group_8.Mahir_2211582;

import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class MonitorInventorySceneController
{
    @javafx.fxml.FXML
    private TableView inventoryTable;
    @javafx.fxml.FXML
    private TableColumn inventoryPriceTC;
    @javafx.fxml.FXML
    private TableColumn inventoryItemIdTC;
    @javafx.fxml.FXML
    private ComboBox inventorySortComboBox;
    @javafx.fxml.FXML
    private TableColumn inventoryNameTC;
    @javafx.fxml.FXML
    private TableColumn inventoryQuantityTC;

    @javafx.fxml.FXML
    public void initialize() {
    }}