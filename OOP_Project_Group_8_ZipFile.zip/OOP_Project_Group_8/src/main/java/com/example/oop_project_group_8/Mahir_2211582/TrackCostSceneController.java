package com.example.oop_project_group_8.Mahir_2211582;

import javafx.event.ActionEvent;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;

public class TrackCostSceneController
{
    @javafx.fxml.FXML
    private Label totalInventoryValueLabel;
    @javafx.fxml.FXML
    private PieChart costTrackingPieChart;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void costBreakdownButtonOnClicked(ActionEvent actionEvent) {
    }
}