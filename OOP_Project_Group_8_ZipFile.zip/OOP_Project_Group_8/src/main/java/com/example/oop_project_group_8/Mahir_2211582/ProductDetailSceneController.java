package com.example.oop_project_group_8.Mahir_2211582;

import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

public class ProductDetailSceneController
{
    @javafx.fxml.FXML
    private ImageView productImage;
    @javafx.fxml.FXML
    private Label availabilityLabel;
    @javafx.fxml.FXML
    private Label productNameLabel;
    @javafx.fxml.FXML
    private Label priceLabel;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void addToCartButtonOnClicked(ActionEvent actionEvent) {
    }
}